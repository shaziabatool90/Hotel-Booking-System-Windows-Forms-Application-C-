﻿
namespace DP_Project.Properties
{
    public interface IRoom
    {
        string Description { get; }
        decimal GetCost();
        string GetDescription();
    }

    public class StandardRoom : IRoom
    {
        public string Description
        {
            get { return "Standard Room"; }
        }

        public decimal GetCost()
        {
            return 5000;
        }

        public string GetDescription()
        {
            return Description;
        }
    }

    public class DeluxeRoom : IRoom
    {
        public string Description
        {
            get { return "Deluxe Room"; }
        }

        public decimal GetCost()
        {
            return 8000;
        }

        public string GetDescription()
        {
            return Description;
        }
    }

    public class SuiteRoom : IRoom
    {
        public string Description
        {
            get { return "Suite Room"; }
        }

        public decimal GetCost()
        {
            return 12000;
        }

        public string GetDescription()
        {
            return Description;
        }
    }

    // Abstract Creator
    public abstract class RoomFactory
    {
        // Factory Method
        public abstract IRoom CreateRoom();

        public string GetRoomInfo()
        {
            IRoom room = CreateRoom();
            return room.GetDescription() + " ($" + room.GetCost() + "/night)";
        }
    }

    // Concrete Creators
    public class StandardRoomFactory : RoomFactory
    {
        public override IRoom CreateRoom()
        {
            return new StandardRoom();
        }
    }

    public class DeluxeRoomFactory : RoomFactory
    {
        public override IRoom CreateRoom()
        {
            return new DeluxeRoom();
        }
    }

    public class SuiteRoomFactory : RoomFactory
    {
        public override IRoom CreateRoom()
        {
            return new SuiteRoom();
        }
    }


}
